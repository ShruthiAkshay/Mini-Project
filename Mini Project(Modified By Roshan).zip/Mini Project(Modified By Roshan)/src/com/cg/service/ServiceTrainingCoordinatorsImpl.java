package com.cg.service;

import java.util.List;

import com.cg.bean.EmployeeMasterBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.bean.TrainingParticipantEnrollmentBean;
import com.cg.bean.TrainingProgramBean;
import com.cg.exception.FeedBackException;

public class ServiceTrainingCoordinatorsImpl implements IServiceTrainingCoordinators {

	@Override
	public boolean trainingProgramMaintenance(
			TrainingProgramBean trainingProgram) throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean participantEnrollment(
			TrainingParticipantEnrollmentBean participant)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean employeeParticipant(EmployeeMasterBean employee)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<TrainingProgramBean> viewTrainingProgram()
			throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateTraining(TrainingProgramBean trainingProgram)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteTraining(String trainingCode) throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<FeedbackMasterBean> viewTrainingProgramReport(int month)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TrainingProgramBean retrieveTraining(String trainingCode) {
		// TODO Auto-generated method stub
		return null;
	}

	


}
