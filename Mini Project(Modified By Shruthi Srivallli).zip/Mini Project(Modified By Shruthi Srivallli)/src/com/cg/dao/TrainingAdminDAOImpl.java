package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;
import com.cg.util.DBConnection;

public class TrainingAdminDAOImpl implements ITrainingAdminDAO 
{

	@Override
	public boolean facultyMaintenance(FacultySkillBean faculty)
			throws FeedBackException {
		
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		

		boolean isInserted=false;
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.FACULTY_MAINTENANCE);

						preparedStatement.setString(1, faculty.getFacultyCode());
						preparedStatement.setString(2, faculty.getSkillSet());
						preparedStatement.setString(3, faculty.getFacultyName());
						queryResult=preparedStatement.executeUpdate();
						if(queryResult>0)
						{
							isInserted=true;
						}
						else
						{
							isInserted=false;
						}

		}
		catch(SQLException sqlException)
		{
			
			throw new FeedBackException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				
				throw new FeedBackException("Error in closing db connection");

			}
		}
		
		return isInserted;
	}

	@Override
	public boolean courseMaintenance(CourseMasterBean course)
			throws FeedBackException {
		
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		

		boolean isInserted=false;
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.COURSE_MAINTENANCE);

				
						preparedStatement.setString(1, course.getCourseName());
						preparedStatement.setInt(2, course.getNoOfDays());
						queryResult=preparedStatement.executeUpdate();
						if(queryResult>0)
						{
							isInserted=true;
						}
						else
						{
							isInserted=false;
						}

		}
		catch(SQLException sqlException)
		{
			
			throw new FeedBackException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				
				throw new FeedBackException("Error in closing db connection");

			}
		}
		
		return isInserted;
		
		
	}

	@Override
	public List<FacultySkillBean> viewFaculty() throws FeedBackException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int facultyCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<FacultySkillBean> facultyList=new ArrayList<FacultySkillBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.VIEW_FACULTY_MAINTENANCE);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				FacultySkillBean facultySkillbean=new FacultySkillBean();
				facultySkillbean.setFacultyName(resultset.getString(1));
				facultySkillbean.setSkillSet(resultset.getString(2));
			
				facultyList.add(facultySkillbean);
				
				facultyCount++;
			}			
			
		} catch (SQLException sqlException) {
			/*logger.error(sqlException.getMessage());*/
			throw new FeedBackException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				/*logger.error(e.getMessage());*/
				throw new FeedBackException("Error in closing db connection");

			}
		}
		
		if( facultyCount == 0)
			return null;
		else
			return facultyList;
	}
		
		


	@Override
	public boolean updateFaculty(FacultySkillBean faculty)
			throws FeedBackException {
		boolean isUpdated=false;
		
		
		return isUpdated;
	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<FeedbackMasterBean> viewFacultyWiseReport(int month)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FacultySkillBean retrieveFaculty(String facultyCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) {
		// TODO Auto-generated method stub
		return null;
	}


}

