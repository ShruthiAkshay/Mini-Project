package com.cg.bean;

public class TrainingParticipantEnrollmentBean {
	
	private String trainingCode;
	private String participantCode;
	public TrainingParticipantEnrollmentBean() {
		super();
	}
	public TrainingParticipantEnrollmentBean(String trainingCode,
			String participantCode) {
		super();
		this.trainingCode = trainingCode;
		this.participantCode = participantCode;
	}
	public String getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(String trainingCode) {
		this.trainingCode = trainingCode;
	}
	public String getParticipantCode() {
		return participantCode;
	}
	public void setParticipantCode(String participantCode) {
		this.participantCode = participantCode;
	}
	@Override
	public String toString() {
		return "TrainingParticipantEnrollmentBean [trainingCode="
				+ trainingCode + ", participantCode=" + participantCode + "]";
	}
	
	
	}
