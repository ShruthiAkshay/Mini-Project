package com.cg.pi;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.TrainingProgramBean;


public class FeedBackManagementSystemMain {
	
	public static void main(String[] args) {
		
	
	TrainingProgramBean trainingProgramBean = new TrainingProgramBean();
	CourseMasterBean courseMasterBean = new CourseMasterBean();
	FacultySkillBean facultySkillBean = new FacultySkillBean();

	trainingProgramBean.setTrainingCode("1");

	
	
	}
}
