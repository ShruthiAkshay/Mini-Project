package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.StockBean;
import com.cg.exception.ShareException;
import com.cg.service.IServiceStock;


@Controller
public class ShareController {
	
	@Autowired
	private IServiceStock serviceStock;
	@RequestMapping("/showHome")
	public ModelAndView showHomePage(@ModelAttribute("stock") StockBean bean, 
			BindingResult result) {
		
		ModelAndView mv = new ModelAndView();
		
		if (result.hasErrors()) {
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		} else {
		try {
			List<StockBean> list= serviceStock.retrieveAllStocks();
			mv.setViewName("index");
			mv.addObject("list", list);
		} catch (ShareException e) {
			mv.setViewName("error");
			mv.addObject("message", e.getMessage());
		}
		
		}
		return mv;
	
	}
}
