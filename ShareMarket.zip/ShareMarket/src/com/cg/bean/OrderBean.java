package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "order_master")
public class OrderBean {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "order_id")
	private int orderId ;
	
	@Column(name = "stock")
	private String stockName;
	
	@Column(name = "quote")
	private double quote;
	
	@Column(name = "order_amount")
	private double orderAmount;
	
	@Column(name = "commission")
	private double commission;

}
