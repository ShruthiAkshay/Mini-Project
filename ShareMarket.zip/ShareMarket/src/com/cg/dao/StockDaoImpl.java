package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.StockBean;
import com.cg.exception.ShareException;


@Repository
@Transactional
public class StockDaoImpl implements IStockDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public List<StockBean> retrieveAllStocks() throws ShareException {
		List<StockBean> list = null;
		
		try {
			TypedQuery<StockBean> query = entityManager.createQuery("from StockBean",StockBean.class);
			list= query.getResultList();
		} catch (Exception e) {
			throw new ShareException("Unable to retrieve all records in dao layer"+e.getMessage());
			
		}
		return list;
	}

}
